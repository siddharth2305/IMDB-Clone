# imDB-Clone
Create a mini IMDB clone app. With some basic features using HTML, CSS &amp; JavaScript
![imdb clone](https://user-images.githubusercontent.com/99132893/215008367-2339252e-bc35-4236-b64a-fc1a36edae43.jpg)